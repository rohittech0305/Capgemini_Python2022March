def secondfunc():
    print("I am from second function in secondprog")