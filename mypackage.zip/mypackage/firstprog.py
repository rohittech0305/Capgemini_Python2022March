def firstfunc():
    print("I am from first function in firstprog")